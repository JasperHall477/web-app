
async function getStorageData(keys) {
  return new Promise((resolve) => {
    chrome.storage.sync.get(keys, (result) => resolve(result));
  });
}

async function loginFromPopup() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const statusText = document.getElementById('statusText');

  statusText.textContent = 'Logging in...';
  statusText.style.color = 'orange';

  try {
    const response = await fetch('http://localhost:3000/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });

    const data = await response.json();

    if (response.ok) {
      await chrome.storage.sync.set({ token: data.token, userId: data.userId });
      statusText.textContent = 'Login successful! Scanning site...';
      statusText.style.color = 'green';
      runSiteCheck();
    } else {
      statusText.textContent = data.message || 'Login failed';
      statusText.style.color = 'red';
    }
  } catch (error) {
    console.error('Login error:', error);
    statusText.textContent = 'Error during login';
    statusText.style.color = 'red';
  }
}

async function runSiteCheck() {
  const statusText = document.getElementById('statusText');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const fullUrl = tab.url;
  const domain = new URL(fullUrl).hostname;

  statusText.textContent = `Checking SSL and Safe Browsing for: ${domain}`;
  statusText.style.color = 'orange';

  const safeBrowsingResult = await checkSafeBrowsing(fullUrl);
  const sslData = await checkSSLCertificate(domain);

  await sendCheckResultsToBackend(domain, safeBrowsingResult, sslData);
  displayResultsInTable(domain, safeBrowsingResult, sslData);

  statusText.textContent = 'Site check data sent to the backend.';
  statusText.style.color = 'green';
}

document.addEventListener('DOMContentLoaded', async () => {
  const loginForm = document.getElementById('loginForm');
  const resultsTable = document.getElementById('resultsTable');
  const statusText = document.getElementById('statusText');
  const loginButton = document.getElementById('loginButton');

  const { token, userId } = await getStorageData(['token', 'userId']);

  if (!token || !userId) {
    loginForm.style.display = 'flex';
    resultsTable.style.display = 'none';
    statusText.textContent = 'Please log in to scan sites.';
    statusText.style.color = 'red';
    loginButton.addEventListener('click', loginFromPopup); // Bind event here
  } else {
    loginForm.style.display = 'none';
    resultsTable.style.display = 'table';
    runSiteCheck();
  }
});
// document.addEventListener('DOMContentLoaded', async () => {
//   const statusText = document.getElementById('statusText');

//   // Get the current active tab's URL
//   const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
//   const domain = new URL(tab.url).hostname;  // This gets the domain (hostname) of the URL
//   console.log("Current domain:", domain);


//   statusText.textContent = `Checking SSL and Safe Browsing for: ${domain}`;
//   statusText.style.color = "orange"; // Temporary color while checking

//   // Call SSL and Safe Browsing check functions
//   const safeBrowsingResult = await checkSafeBrowsing(domain);
//   const sslData = await checkSSLCertificate(domain);


//   // Send the results to the backend (MongoDB)
//   await sendCheckResultsToBackend(domain, safeBrowsingResult, sslData);

//   // Display results locally in the extension in table format
//   displayResultsInTable(domain, safeBrowsingResult, sslData);

//   statusText.textContent = "Site check data sent to the backend.";
//   statusText.style.color = "green";
// });

// Safe Browsing Check
async function checkSafeBrowsing(domain) {
  const API_KEY = 'AIzaSyDjmB_KVoO-bF0wf-7ZjzdOpMa1xMl1OTI';  // Safe Browsing API key
  const apiUrl = `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${API_KEY}`;

  const body = {
    client: {
      clientId: "student",
      clientVersion: "1.0"
    },
    threatInfo: {
      threatTypes: ["MALWARE", "SOCIAL_ENGINEERING"],
      platformTypes: ["ANY_PLATFORM"],
      threatEntryTypes: ["URL"],
      threatEntries: [{ url: `http://${domain}` }]
    }
  };

  try {
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      throw new Error('Error fetching Safe Browsing data');
    }

    const data = await response.json();
    return { isPhishing: !!data.matches };
  } catch (error) {
    console.error("Error fetching Safe Browsing data:", error);
    return { isPhishing: false };
  }
}

// SSL Certificate Check
async function checkSSLCertificate(domain) {
  const apiUrl = `https://whoisjson.com/api/v1/ssl-cert-check?domain=${domain}`;

  try {
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Authorization': 'TOKEN=d26b1f52068d1d7ebcd0e8e8be15e94cc153ea6d8081ab7f25481343bcaa1e54' 
      }
    });

    if (!response.ok) {
      throw new Error('Error fetching SSL certificate data');
    }

    const data = await response.json();
    return { valid: data.valid, validUntil: data.valid_to };
  } catch (error) {
    console.error("Error fetching SSL certificate data:", error);
    return { valid: false, message: error.message };
  }
}

function getStorageData(keys) {
  return new Promise((resolve) => {
    chrome.storage.sync.get(keys, (data) => resolve(data));
  });
}



async function sendCheckResultsToBackend(domain, safeBrowsingResult, sslData) {
  const { token, userId } = await getStorageData(['token', 'userId']);
  if (!token || !userId) {
    console.error('Missing token or userId. Please log in.');
    return;
  }

  const checkResult = {
    phishing: safeBrowsingResult.isPhishing ? 'Unsafe' : 'Safe',
    ssl: sslData.valid ? `Valid until ${sslData.validUntil}` : 'Invalid'
  };

  try {
    const response = await fetch('http://localhost:3000/api/addSiteCheck', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ userId, url: domain, checkResult })
    });

    if (!response.ok) throw new Error('Failed to send site check');
  } catch (error) {
    console.error('Error sending site check:', error);
  }
}
// async function sendCheckResultsToBackend(domain, safeBrowsingResult, sslData) {
//   const { token, userId } = await getStorageData(['token', 'userId']);
//   console.log('Retrieved from chrome.storage:', { token, userId });

//   if (!token || !userId) {
//     document.getElementById('statusText').textContent =
//       'Please log in via the web app first (http://localhost:3000)';
//     document.getElementById('statusText').style.color = 'red';
//     console.error('Missing token or userId. Please log in via the web app.');
//     return;
//   }

//   console.log("UserId being sent:", userId);

//   const payload = {
//     url: domain,
//     checkResult: {
//       phishing: safeBrowsingResult.isPhishing ? "Unsafe" : "Safe",
//       ssl: sslData.valid ? "Valid" : "Invalid",
//     },
//     validUntil: sslData.valid ? sslData.validUntil : null,
//     userId: userId,
//   };

//   console.log("Data being sent to the backend:", payload);

//   try {
//     const response = await fetch('http://localhost:3000/api/addSiteCheck', {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//         'Authorization': `Bearer ${token}`,
//       },
//       body: JSON.stringify(payload),
//     });

//     if (response.ok) {
//       console.log('Site check data sent to backend successfully');
//       document.getElementById('statusText').textContent = 'Site check saved!';
//       document.getElementById('statusText').style.color = 'green';
//     } else {
//       const errorText = await response.json();
//       console.error('Failed to send data to backend:', response.status, errorText);
//       document.getElementById('statusText').textContent = `Error: ${errorText.message}`;
//       document.getElementById('statusText').style.color = 'red';
//     }
//   } catch (error) {
//     console.error('Error sending data to backend:', error);
//     document.getElementById('statusText').textContent = 'Network error occurred';
//     document.getElementById('statusText').style.color = 'red';
//   }
// }

 

// Display results locally in the extension in table format
function displayResultsInTable(domain, safeBrowsingResult, sslData) {
  const tbody = document.querySelector('#resultsTable tbody');
  tbody.innerHTML = '';

  const phishingRow = document.createElement('tr');
  phishingRow.innerHTML = `<td>Phishing</td><td style="color: ${safeBrowsingResult.isPhishing ? 'red' : 'green'}">${safeBrowsingResult.isPhishing ? 'Unsafe' : 'Safe'}</td>`;
  tbody.appendChild(phishingRow);

  const sslRow = document.createElement('tr');
  sslRow.innerHTML = `<td>SSL</td><td style="color: ${sslData.valid ? 'green' : 'red'}">${sslData.valid ? `Valid until ${sslData.validUntil}` : 'Invalid'}</td>`;
  tbody.appendChild(sslRow);
}
// function displayResultsInTable(domain, safeBrowsingResult, sslData) {
//   const resultContainer = document.getElementById('results');
//   const phishingStatus = safeBrowsingResult.isPhishing ? "Unsafe" : "Safe";
//   const sslStatus = sslData.valid ? "Valid" : "Invalid";
//   const validUntil = sslData.valid ? `Valid until ${new Date(sslData.validUntil).toLocaleDateString()}` : "";

//   // Create a table to display the results
//   const table = document.createElement('table');
//   table.style.width = '100%';
//   table.style.border = '1px solid black';
//   table.style.borderCollapse = 'collapse';

//   // Create table header
//   const header = table.createTHead();
//   const headerRow = header.insertRow();
//   headerRow.insertCell().textContent = 'Check';
//   headerRow.insertCell().textContent = 'Status';

//   // Create table body
//   const body = table.createTBody();
//   const phishingRow = body.insertRow();
//   phishingRow.insertCell().textContent = 'Safe Browsing';
//   const phishingCell = phishingRow.insertCell();
//   phishingCell.textContent = phishingStatus;
//   phishingCell.style.color = safeBrowsingResult.isPhishing ? "red" : "green";

//   const sslRow = body.insertRow();
//   sslRow.insertCell().textContent = 'SSL Certificate';
//   const sslCell = sslRow.insertCell();
//   sslCell.textContent = `${sslStatus} ${validUntil}`;
//   sslCell.style.color = sslData.valid ? "green" : "red";

//   // Append the table to the result container
//   resultContainer.innerHTML = '';  // Clear any previous content
//   resultContainer.appendChild(table);
// }
