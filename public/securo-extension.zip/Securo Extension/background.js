// Example: sending a POST request with the JWT token to the backend
function sendSiteCheckData(domain, checkResult) {
    chrome.storage.local.get(['token', 'userId'], function(result) {
      const token = result.token;
      const userId = result.userId;
  
      if (!token || !userId) {
        console.log("User is not logged in");
        return;
      }
  
      const data = {
        url: domain,
        checkResult: checkResult,
        userId: userId
      };
      
      fetch('https://web-app-j994.onrender.com/api/addSiteCheck', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`  // Send JWT token for authentication
        },
        body: JSON.stringify(data)
      })
      .then(response => response.json())
      .then(responseData => {
        console.log("Data sent to the backend:", responseData);
      })
      .catch(error => {
        console.error("Error sending data to the backend:", error);
      });
    });
  }
  