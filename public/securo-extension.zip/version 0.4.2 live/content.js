// Listen for token and userId being set in localStorage
window.addEventListener('storage', (event) => {
    if (event.key === 'token' || event.key === 'userId') {
      const token = localStorage.getItem('token');
      const userId = localStorage.getItem('userId');
      if (token && userId) {
        chrome.storage.sync.set({ token, userId }, () => {
          console.log('Token and userId synced to chrome.storage from localStorage');
        });
      }
    }
  });
  
  // Initial check in case storage is already set
  const token = localStorage.getItem('token');
  const userId = localStorage.getItem('userId');
  if (token && userId) {
    chrome.storage.sync.set({ token, userId }, () => {
      console.log('Initial sync: Token and userId saved to chrome.storage');
    });
  }