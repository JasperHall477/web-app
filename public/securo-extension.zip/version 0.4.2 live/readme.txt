added automatic detection if newly installed extension it asks user to login before allowing scans
this version is coded to work on local development only