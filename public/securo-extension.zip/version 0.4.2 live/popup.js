
async function getStorageData(keys) {
  return new Promise((resolve) => {
    chrome.storage.sync.get(keys, (result) => resolve(result));
  });
}

async function loginFromPopup() {
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const statusText = document.getElementById('statusText');

  statusText.textContent = 'Logging in...';
  statusText.style.color = 'orange';

  try {
    console.log('Sending login request:', { username, password });
    const response = await fetch('https://web-app-j994.onrender.com/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    console.log('Response status:', response.status);
    console.log('Response headers:', Object.fromEntries(response.headers));

    const text = await response.text(); // Get raw text first
    console.log('Response body:', text); // Log it
    const data = JSON.parse(text); // Then parse

    if (response.ok) {
      await chrome.storage.sync.set({ token: data.token, userId: data.userId });
      statusText.textContent = 'Login successful! Scanning site...';
      statusText.style.color = 'green';
      runSiteCheck();
    } else {
      statusText.textContent = data.message || 'Login failed';
      statusText.style.color = 'red';
    }
  } catch (error) {
    console.error('Login error:', error);
    statusText.textContent = 'Error during login: ' + error.message;
    statusText.style.color = 'red';
  }
}

async function runSiteCheck() {
  const statusText = document.getElementById('statusText');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const fullUrl = tab.url;
  const domain = new URL(fullUrl).hostname;

  statusText.textContent = `Checking SSL and Safe Browsing for: ${domain}`;
  statusText.style.color = 'orange';

  const safeBrowsingResult = await checkSafeBrowsing(fullUrl);
  const sslData = await checkSSLCertificate(domain);

  await sendCheckResultsToBackend(domain, safeBrowsingResult, sslData);
  displayResultsInTable(domain, safeBrowsingResult, sslData);

  statusText.textContent = 'Site check data sent to the backend.';
  statusText.style.color = 'green';
}

document.addEventListener('DOMContentLoaded', async () => {
  const loginForm = document.getElementById('loginForm');
  const resultsTable = document.getElementById('resultsTable');
  const statusText = document.getElementById('statusText');
  const loginButton = document.getElementById('loginButton');

  const { token, userId } = await getStorageData(['token', 'userId']);

  if (!token || !userId) {
    loginForm.style.display = 'flex';
    resultsTable.style.display = 'none';
    statusText.textContent = 'Please log in to scan sites.';
    statusText.style.color = 'red';
    loginButton.addEventListener('click', loginFromPopup); // Bind event here
  } else {
    loginForm.style.display = 'none';
    resultsTable.style.display = 'table';
    runSiteCheck();
  }
});

// Safe Browsing Check
async function checkSafeBrowsing(domain) {
  const API_KEY = 'AIzaSyDjmB_KVoO-bF0wf-7ZjzdOpMa1xMl1OTI';  // Safe Browsing API key
  const apiUrl = `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${API_KEY}`;

  const body = {
    client: {
      clientId: "student",
      clientVersion: "1.0"
    },
    threatInfo: {
      threatTypes: ["MALWARE", "SOCIAL_ENGINEERING"],
      platformTypes: ["ANY_PLATFORM"],
      threatEntryTypes: ["URL"],
      threatEntries: [{ url: `http://${domain}` }]
    }
  };

  try {
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    if (!response.ok) {
      throw new Error('Error fetching Safe Browsing data');
    }

    const data = await response.json();
    return { isPhishing: !!data.matches };
  } catch (error) {
    console.error("Error fetching Safe Browsing data:", error);
    return { isPhishing: false };
  }
}

// SSL Certificate Check
async function checkSSLCertificate(domain) {
  const apiUrl = `https://whoisjson.com/api/v1/ssl-cert-check?domain=${domain}`;

  try {
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Authorization': 'TOKEN=d26b1f52068d1d7ebcd0e8e8be15e94cc153ea6d8081ab7f25481343bcaa1e54' 
      }
    });

    if (!response.ok) {
      throw new Error('Error fetching SSL certificate data');
    }

    const data = await response.json();
    return { valid: data.valid, validUntil: data.valid_to };
  } catch (error) {
    console.error("Error fetching SSL certificate data:", error);
    return { valid: false, message: error.message };
  }
}

function getStorageData(keys) {
  return new Promise((resolve) => {
    chrome.storage.sync.get(keys, (data) => resolve(data));
  });
}



async function sendCheckResultsToBackend(domain, safeBrowsingResult, sslData) {
  const { token, userId } = await getStorageData(['token', 'userId']);
  if (!token || !userId) {
    console.error('Missing token or userId. Please log in.');
    return;
  }

  const checkResult = {
    phishing: safeBrowsingResult.isPhishing ? 'Unsafe' : 'Safe',
    ssl: sslData.valid ? `Valid until ${sslData.validUntil}` : 'Invalid'
  };

  try {
    const response = await fetch('https://web-app-j994.onrender.com/api/addSiteCheck', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ userId, url: domain, checkResult })
    });

    if (!response.ok) throw new Error('Failed to send site check');
  } catch (error) {
    console.error('Error sending site check:', error);
  }
}

 

// Display results locally in the extension in table format
function displayResultsInTable(domain, safeBrowsingResult, sslData) {
  const tbody = document.querySelector('#resultsTable tbody');
  tbody.innerHTML = '';

  const phishingRow = document.createElement('tr');
  phishingRow.innerHTML = `<td>Phishing</td><td style="color: ${safeBrowsingResult.isPhishing ? 'red' : 'green'}">${safeBrowsingResult.isPhishing ? 'Unsafe' : 'Safe'}</td>`;
  tbody.appendChild(phishingRow);

  const sslRow = document.createElement('tr');
  sslRow.innerHTML = `<td>SSL</td><td style="color: ${sslData.valid ? 'green' : 'red'}">${sslData.valid ? `Valid until ${sslData.validUntil}` : 'Invalid'}</td>`;
  tbody.appendChild(sslRow);
}
