async function getStorageData() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(['token', 'userId'], (result) => resolve(result));
  });
}

// Begin scan
async function runSiteCheck() {
  const statusText = document.getElementById('statusText');

  // Get the URL of the active tab to scan
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const fullUrl = tab.url;
  const domain = new URL(fullUrl).hostname;

  // Notify that check has begun for user
  statusText.textContent = `Checking ${domain}...`;
  statusText.style.color = '#007bff'; 

  // Run individual security checks with the current URL
  const safeBrowsingResult = await checkSafeBrowsing(fullUrl);
  const sslData = await checkSSLCertificate(domain);
  const mlResult = await checkURLSafety(fullUrl);
  const virusTotalResult = await checkVirusTotal(fullUrl);

  // Send results to backend server for storage in database
  await sendCheckResultsToBackend(domain, safeBrowsingResult, sslData, mlResult, virusTotalResult);

  // Display the results immediately to user in the popup table
  displayResultsInTable(domain, safeBrowsingResult, sslData, mlResult, virusTotalResult);

  // Update the status text from checking to complete once done
  statusText.textContent = 'Check complete!';
  statusText.style.color = '#28a745'; // Green for success
}

async function checkURLSafety(url) {
  try {
    const response = await fetch('https://url-safety-server.onrender.com/api/check-url', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url })
    });
    if (!response.ok) throw new Error(`HTTP error ${response.status}`);
    const data = await response.json();
    console.log('URL Safety Check Response:', data);
    return { isSafe: data.isSafe };
  } catch (error) {
    console.error('Error checking URL safety:', error);
    return { isSafe: true }; // Default to safe on failure
  }
}

async function checkVirusTotal(domain) {
  try {
    const response = await fetch('https://web-app-j994.onrender.com/api/virustotal-check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url: domain })
    });

    if (!response.ok) throw new Error('VirusTotal check failed');

    const data = await response.json();
    console.log('VirusTotal Check Response:', data);
    return { verdict: data.verdict, positives: data.positives, total: data.total };
  } catch (error) {
    console.error('VirusTotal error:', error);
    return { verdict: 'Not Scanned'}
  }
}

async function checkSafeBrowsing(domain) {
  const API_KEY = 'AIzaSyDjmB_KVoO-bF0wf-7ZjzdOpMa1xMl1OTI';
  const apiUrl = `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${API_KEY}`;

  const body = {
    client: { clientId: "student", clientVersion: "1.0" },
    threatInfo: {
      threatTypes: ["MALWARE", "SOCIAL_ENGINEERING"],
      platformTypes: ["ANY_PLATFORM"],
      threatEntryTypes: ["URL"],
      threatEntries: [{ url: domain }]
    }
  };

  try {
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });

    if (!response.ok) throw new Error('Safe Browsing API error');
  
    const data = await response.json();
    console.log('Safe Browsing Response:', data);
    return { isPhishing: !!data.matches };
  } catch (error) {
    console.error('Error fetching Safe Browsing data:', error);
    return { isPhishing: false };
  }
}

async function checkSSLCertificate(domain) {
  const apiUrl = `https://whoisjson.com/api/v1/ssl-cert-check?domain=${domain}`;
  try {
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Authorization': 'TOKEN=d26b1f52068d1d7ebcd0e8e8be15e94cc153ea6d8081ab7f25481343bcaa1e54'
      }
    });
    if (!response.ok) throw new Error('SSL API error');
    const data = await response.json();
    console.log('SSL Certificate Check Response:', data);
    return { valid: data.valid, validUntil: data.valid_to };
  } catch (error) {
    console.error('Error fetching SSL certificate data:', error);
    return { valid: false, message: error.message };
  }
}

// Sends the results of a site check to the backend server to be stored in the DB
async function sendCheckResultsToBackend(domain, safeBrowsingResult, sslData, mlResult, virusTotalResult) {
  // Get the JWT token and userID from chrome storage
  const { token, userId } = await getStorageData();
  // If we cant find them, get them to login before continuing
  if (!token || !userId) {
    document.getElementById('statusText').textContent = 'Please log in via the web app (https://web-app-j994.onrender.com)';
    document.getElementById('statusText').style.color = '#dc3545';
    return;
  }

  // Format the check results to be sent to the backend server
  const checkResult = {
    phishing: safeBrowsingResult.isPhishing ? 'Unsafe' : 'Safe',
    ssl: sslData.valid ? 'Valid' : 'Invalid',
    mlPrediction: mlResult.isSafe ? 'Safe' : 'Unsafe',
  };

  try {
    // Make a POST request to the backend API to store the site check 
    const response = await fetch('https://web-app-j994.onrender.com/api/addSiteCheck', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({
        url: domain,
        checkResult,
        validUntil: sslData.validUntil,
        virusTotal: virusTotalResult
      })
    });
    // Throw an error if the response is bad
    if (!response.ok) throw new Error('Backend sync failed');
  } catch (error) {
    // Log the error to console (for local dev)
    console.error('Error sending site check:', error);
  }
}

function displayResultsInTable(domain, safeBrowsingResult, sslData, mlResult, virusTotalResult) {
  const tbody = document.querySelector('#resultsTable tbody');
  tbody.innerHTML = '';

  const rows = [
    { label: 'Phishing', value: safeBrowsingResult.isPhishing ? 'Unsafe' : 'Safe', color: safeBrowsingResult.isPhishing ? '#dc3545' : '#28a745' },
    { label: 'SSL', value: sslData.valid ? `Valid until ${new Date(sslData.validUntil).toLocaleDateString()}` : 'Invalid', color: sslData.valid ? '#28a745' : '#dc3545' },
    { label: 'ML Prediction', value: mlResult.isSafe ? 'Safe' : 'Unsafe', color: mlResult.isSafe ? '#28a745' : '#dc3545' },
    {
      label: 'VirusTotal',
      value: virusTotalResult.positives !== undefined && virusTotalResult.total !== undefined
        ? `${virusTotalResult.verdict} (${virusTotalResult.positives}/${virusTotalResult.total})`
        : virusTotalResult.verdict,
      color:
        virusTotalResult.verdict === 'Safe' ? '#28a745' :
        virusTotalResult.verdict === 'Suspicious' ? '#FFA500' : '#dc3545'
    }
  ];

  rows.forEach(row => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${row.label}</td><td style="color: ${row.color}">${row.value}</td>`;
    tbody.appendChild(tr);
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  const resultsTable = document.getElementById('resultsTable');
  const statusText = document.getElementById('statusText');

  const { token, userId } = await getStorageData();
  console.log('Retrieved from storage:', { token, userId });

  if (token && userId) {
    resultsTable.style.display = 'table';
    runSiteCheck();
  } else {
    resultsTable.style.display = 'none';
    statusText.textContent = 'Please log in via the web app (https://web-app-j994.onrender.com)';
    statusText.style.color = '#dc3545';
  }
});