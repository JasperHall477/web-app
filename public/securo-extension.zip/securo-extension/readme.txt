added automatic detection if newly installed extension it asks user to login before allowing scans
this version is coded to work on local development only
issue where it stays using initial user account that is logged in even if they logout and login as someone else on the web app