let lastToken = null;
let lastUserId = null;

function syncCredentials() {
  const token = localStorage.getItem('token');
  const userId = localStorage.getItem('userId');

  if (token !== lastToken || userId !== lastUserId) {
    lastToken = token;
    lastUserId = userId;

    if (token && userId) {
      chrome.storage.sync.set({ token, userId }, () => {
        console.log('Synced token and userId to chrome.storage:', token, userId);
      });
    }
  }
}

// Initial sync
syncCredentials();

// Poll every 10 seconds instead of 1
setInterval(syncCredentials, 10000); // 10,000 ms = 10 seconds
