async function getStorageData() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(['token', 'userId'], (result) => resolve(result));
  });
}

async function runSiteCheck() {
  const statusText = document.getElementById('statusText');
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const fullUrl = tab.url;
  const domain = new URL(fullUrl).hostname;

  statusText.textContent = `Checking ${domain}...`;
  statusText.style.color = '#007bff'; // Blue for in-progress

  const safeBrowsingResult = await checkSafeBrowsing(fullUrl);
  const sslData = await checkSSLCertificate(domain);
  const mlResult = await checkURLSafety(fullUrl);

  await sendCheckResultsToBackend(domain, safeBrowsingResult, sslData, mlResult);
  displayResultsInTable(domain, safeBrowsingResult, sslData, mlResult);

  statusText.textContent = 'Check complete!';
  statusText.style.color = '#28a745'; // Green for success
}

async function checkURLSafety(url) {
  try {
    const response = await fetch('https://url-safety-server.onrender.com/api/check-url', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url })
    });
    if (!response.ok) throw new Error(`HTTP error ${response.status}`);
    const data = await response.json();
    return { isSafe: data.isSafe };
  } catch (error) {
    console.error('Error checking URL safety:', error);
    return { isSafe: true }; // Default to safe on failure
  }
}

async function checkSafeBrowsing(domain) {
  const API_KEY = 'AIzaSyDjmB_KVoO-bF0wf-7ZjzdOpMa1xMl1OTI';
  const apiUrl = `https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${API_KEY}`;

  const body = {
    client: { clientId: "student", clientVersion: "1.0" },
    threatInfo: {
      threatTypes: ["MALWARE", "SOCIAL_ENGINEERING"],
      platformTypes: ["ANY_PLATFORM"],
      threatEntryTypes: ["URL"],
      threatEntries: [{ url: domain }]
    }
  };

  try {
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    if (!response.ok) throw new Error('Safe Browsing API error');
    const data = await response.json();
    return { isPhishing: !!data.matches };
  } catch (error) {
    console.error('Error fetching Safe Browsing data:', error);
    return { isPhishing: false };
  }
}

async function checkSSLCertificate(domain) {
  const apiUrl = `https://whoisjson.com/api/v1/ssl-cert-check?domain=${domain}`;
  try {
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Authorization': 'TOKEN=d26b1f52068d1d7ebcd0e8e8be15e94cc153ea6d8081ab7f25481343bcaa1e54'
      }
    });
    if (!response.ok) throw new Error('SSL API error');
    const data = await response.json();
    return { valid: data.valid, validUntil: data.valid_to };
  } catch (error) {
    console.error('Error fetching SSL certificate data:', error);
    return { valid: false, message: error.message };
  }
}

async function sendCheckResultsToBackend(domain, safeBrowsingResult, sslData, mlResult) {
  const { token, userId } = await getStorageData();
  if (!token || !userId) {
    document.getElementById('statusText').textContent = 'Please log in via the web app (https://web-app-j994.onrender.com)';
    document.getElementById('statusText').style.color = '#dc3545';
    return;
  }

  const checkResult = {
    phishing: safeBrowsingResult.isPhishing ? 'Unsafe' : 'Safe',
    ssl: sslData.valid ? 'Valid' : 'Invalid',
    mlPrediction: mlResult.isSafe ? 'Safe' : 'Unsafe'
  };

  try {
    const response = await fetch('https://web-app-j994.onrender.com/api/addSiteCheck', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ url: domain, checkResult, validUntil: sslData.validUntil })
    });
    if (!response.ok) throw new Error('Backend sync failed');
  } catch (error) {
    console.error('Error sending site check:', error);
  }
}

function displayResultsInTable(domain, safeBrowsingResult, sslData, mlResult) {
  const tbody = document.querySelector('#resultsTable tbody');
  tbody.innerHTML = '';

  const rows = [
    { label: 'Phishing', value: safeBrowsingResult.isPhishing ? 'Unsafe' : 'Safe', color: safeBrowsingResult.isPhishing ? '#dc3545' : '#28a745' },
    { label: 'SSL', value: sslData.valid ? `Valid until ${new Date(sslData.validUntil).toLocaleDateString()}` : 'Invalid', color: sslData.valid ? '#28a745' : '#dc3545' },
    { label: 'ML Prediction', value: mlResult.isSafe ? 'Safe' : 'Unsafe', color: mlResult.isSafe ? '#28a745' : '#dc3545' }
  ];

  rows.forEach(row => {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${row.label}</td><td style="color: ${row.color}">${row.value}</td>`;
    tbody.appendChild(tr);
  });
}

document.addEventListener('DOMContentLoaded', async () => {
  const resultsTable = document.getElementById('resultsTable');
  const statusText = document.getElementById('statusText');

  const { token, userId } = await getStorageData();
  console.log('Retrieved from storage:', { token, userId });

  if (token && userId) {
    resultsTable.style.display = 'table';
    runSiteCheck();
  } else {
    resultsTable.style.display = 'none';
    statusText.textContent = 'Please log in via the web app (https://web-app-j994.onrender.com)';
    statusText.style.color = '#dc3545';
  }
});