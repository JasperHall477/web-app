// Listen for changes in localStorage (set by the web app) and sync them to chrome.storage.sync
// window.addEventListener('storage', (event) => {
//   if (event.key === 'token' || event.key === 'userId') {
//     const token = localStorage.getItem('token');
//     const userId = localStorage.getItem('userId');
//     if (token && userId) {
//       chrome.storage.sync.set({ token, userId }, () => {
//         console.log('Token and userId synced to chrome.storage from localStorage');
//       });
//     }
//   }
// });

// // Initial sync: If the token and userId are already set in localStorage, sync them
// const token = localStorage.getItem('token');
// const userId = localStorage.getItem('userId');
// if (token && userId) {
//   chrome.storage.sync.set({ token, userId }, () => {
//     console.log('Initial sync: Token and userId saved to chrome.storage');
//   });
// }

// content.js
function syncCredentials() {
  const token = localStorage.getItem('token');
  const userId = localStorage.getItem('userId');
  if (token && userId) {
    chrome.storage.sync.set({ token, userId }, () => {
      console.log('Synced token and userId to chrome.storage:', token, userId);
    });
  }
}

// Initial sync
syncCredentials();

// Poll for changes (simple alternative to storage event)
setInterval(syncCredentials, 1000); // Check every second
